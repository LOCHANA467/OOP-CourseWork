/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.courier_management;

/**
 *
 * @author ASUS
 */
public class Courier_Management {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
